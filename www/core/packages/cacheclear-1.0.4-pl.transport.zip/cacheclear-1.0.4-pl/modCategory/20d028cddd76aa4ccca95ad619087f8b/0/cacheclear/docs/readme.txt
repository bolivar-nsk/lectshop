
CacheClear

Deletes all files in the core/cache directory

Author: Bob Ray <https://bobsguides.com>
Copyright 2012-2019 Bob Ray

Official Documentation: https://bobsguides.com/cache-clear-tutorial.html

Bugs and Feature Requests: https://github.com/BobRay/CacheClear

Questions: https://forums.modx.com

Created by MyComponent
