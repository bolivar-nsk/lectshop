<?php
require_once (dirname(__DIR__) . '/adminnotes.class.php');
class adminNotes_mysql extends adminNotes {}