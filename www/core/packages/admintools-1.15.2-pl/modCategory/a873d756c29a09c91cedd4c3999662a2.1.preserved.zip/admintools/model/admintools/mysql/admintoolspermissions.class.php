<?php
require_once (dirname(__DIR__) . '/admintoolspermissions.class.php');
class adminToolsPermissions_mysql extends adminToolsPermissions {}