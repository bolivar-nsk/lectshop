<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8b564a3f4471358671fc055301b1b383',
      'native_key' => 'core',
      'filename' => 'modNamespace/f0a18f56745e80d5a1a93c2f249c7204.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '1122da4b8f504fdea3cf1c2110207d54',
      'native_key' => 1,
      'filename' => 'modWorkspace/a6b3b413b134aa4f9f826cc43d667582.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'd57ccaceb4e000818363607c9e9316dd',
      'native_key' => 1,
      'filename' => 'modTransportProvider/9587cc30fc192252887ea0ac88ec4f07.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7b7d617deaf15b400f67aea16fa177dc',
      'native_key' => 'topnav',
      'filename' => 'modMenu/c31e793035c90d42a331f7073f9802f5.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f9474e6fca68ddc4dc765dc32c63457b',
      'native_key' => 'usernav',
      'filename' => 'modMenu/d9a0ce56bfd5d19612648e98afccc90b.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '5e4140620c1be64d6c1a5837dff89f64',
      'native_key' => 1,
      'filename' => 'modContentType/2e5df5e69c32aade1287e386198bd780.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '60c40de602a28415db14e7d2ebd45f04',
      'native_key' => 2,
      'filename' => 'modContentType/925dff538ce158b45c46c783bb3f0db5.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b9fb34a882bfa5e021ff30e0589d9a7a',
      'native_key' => 3,
      'filename' => 'modContentType/956e81344254e0a628c05ef71c440ba0.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '555ad8452839d39d3b6425c3b0ca6eeb',
      'native_key' => 4,
      'filename' => 'modContentType/71e221c78077cadbc386905017a29d1b.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8686241ce07a9b9920cf8165d70d4df2',
      'native_key' => 5,
      'filename' => 'modContentType/f8fe63390e84d01797ed1989eae200f3.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '82291d829c857b9d9e0383cd217dbe52',
      'native_key' => 6,
      'filename' => 'modContentType/c246874262b71ebb73b989a593b1ab60.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '86e37e3f98c37179d90517fb4929548a',
      'native_key' => 7,
      'filename' => 'modContentType/517b27cadcfa40a19405dfae5ea6ee5e.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f50c2cb9faf34716212e46c288ad02fd',
      'native_key' => 8,
      'filename' => 'modContentType/d327c45ec7c4c6940eb4f1fffe8b195b.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8db73bdac3e4e521c5d615327896aaea',
      'native_key' => NULL,
      'filename' => 'modClassMap/d2e9061902e44a96c8a1f4a277c4eebe.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7dcf8c2c1dad378c61096bc5036c5763',
      'native_key' => NULL,
      'filename' => 'modClassMap/5e9b7f096fbf34cd74ad06b19924bdba.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '24e3788b502f5b8362b81c025105ae1a',
      'native_key' => NULL,
      'filename' => 'modClassMap/a90059a5c6a102753a3e07d5da9ac95e.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6a5fac7abaa10ac94e2696b77e35bdf9',
      'native_key' => NULL,
      'filename' => 'modClassMap/523d85f9dddcab6f6de81c6387ee23d7.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '59a92759d7827b60e24a5fdd6884f9bf',
      'native_key' => NULL,
      'filename' => 'modClassMap/f1b3efd1eac239bc72b1425c6578c772.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5152d71d3b8fb3a5c422091c8f1f9494',
      'native_key' => NULL,
      'filename' => 'modClassMap/fa2c6665e7ac309d4041701adb597168.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2245f438b84bc68ab1e7035dadb7c39d',
      'native_key' => NULL,
      'filename' => 'modClassMap/6b74a3345a15ce852f43c1ae4b94c066.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6216307cb8891919e6c1b550096dffd5',
      'native_key' => NULL,
      'filename' => 'modClassMap/1833872cb820e2ebd7364ea3c7aa5e01.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5b768d5b8d69d84ded3e9308fdbb5e69',
      'native_key' => NULL,
      'filename' => 'modClassMap/ecc8455ae23efcdcd508339e880e9959.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '389b9c92226fd31e8114cc8e587b79ae',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/018e341475af45e7f688207c3a601961.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7255da6485c3f981ba4ba379c09ddcf8',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/5a5473d94f3c6309f504ca59191684a1.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd138cf664de1b25b7b39f2bae799dbb5',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/47a0e33eaad8cac71ddb98ee4c9bbba6.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0180a9b55ead3961f3a3a9307f44b85',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/da430d926444f0c56f97584c49210c71.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '842c054e0e97c4abe2cc78f6abaa56ad',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/03600193f42bee24dcc031a8f9c03042.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3dacc2de273153d5cfb37752c5fed145',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/79fccfa3dc8f3bc368a3d1aabeb1fda6.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f54f3a5f54cd16cf4c911b2e327c5feb',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/df080f28268c9b47f778b8513efd14cd.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d31c609b496d288ed54a99000b39be9',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/c7da96aa10382197270de4897a0f749a.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2dff8865ddf6d3694ce365f09db4dfb',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/16c88f39342cd9b1d662f518f7f36c41.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d8cd44581b07aec0a63a1753687d104',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/7c5ff2664064724af2dea6c09a5741a8.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7670bc56fefee8d0a3ec84857327c1a3',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/3dc3063b0f3ed94948141f9e52af4602.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '346da8c61c2016047e1431f014bac64f',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/9223ffd46eee5b30c1f4d7a83f1bd0c3.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65323818d953610645b08c06ba655c2a',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/04dd94e4dfeb6f34b0c5f04af3ba0ff6.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b00ca8fe6f8c3a229d369e5a8ecf0f28',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/398ce210ef670b366fbc2412a82b2184.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ae193ca582c80d101c79dcb6a08431f',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/dc78cddc749f0a8a88ba84e0dbe7ce7c.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'baecc41c8a3acddf3a8696bd078110a6',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/47939b079578cc637220967e4b2e3940.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84d2dbc8b4e9f796a99d3133ab859bbe',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/5a38fc54898d17567579708cf216bcb8.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '642580a0c7a6e3492f1131a595b55952',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/8d37f3bb889c5b3ad14699c525d239f4.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7175c7326882cd8fda152c17e8a89e41',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/55b257656a40986caa2d6f5697ccd62b.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '410763e7b4e70736c5f457aef2807f69',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/c3994d84c82d356be4a8bb7f8d1ccfd0.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9ad8c72cf15b323eb5114009c21c424',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/7e0ec49d5a6499df0dd3f07fb0d9352a.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0bbcf3a56b75a3d6b01bca1ab9c6544e',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/898d64739487160d7951135a513b969a.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06b0ceda25cb8a88cf638f8145274a76',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/f3e2afa97ca2e3f5509bba73be87f579.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f5976cbdec631116c9aa2d61695fdf8',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/fd2587a1aee3e9720f00eb0d9e39182b.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f525d3ac71481347696aa509b2e65107',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/f72054f2f095165edb19a840bd517f5c.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5703c6a9485505557c7599490180a81a',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/05f9698d495e8724287dfe8b1c447120.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17b83028fdb4bfadd38b2419abaaaf75',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/c16b328fedbf4c5f02e3d99852374af7.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b34b208da9b71f53cdb9f7fe93ccf877',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/b354c39583a639d118eb2c72fc85cd73.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c63c33ceacc9b89f03d946c024b66c6a',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/52ed2d4206a9d625e17916f2a4fb90c6.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9454cc930008a326967219f20b0fa945',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/d0826c1926d52fbe3c53d4210270082c.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82f12a574997b1300f91195ab8c2ae5a',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/3d8e95a4a4aeec99ddc4b433cb007cad.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d19338629312b9a976d2ba6eeba9755',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/7fc56877758c4c9133d2a066b6dd6024.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7f28ee44828fadc7c2e2d74aebfb87b',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/67e93fefe0150c229747a7c7cd8a474e.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbaaa11e52e084acda8c7bd15965b6a6',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/bb647c879bafe6c79f7b490f5424edd2.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb0da0c6f9b7d2703bcf40ff85bf6ed4',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/4c3a3d76805612eedb1bfac505a361a3.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55299dbb5f2df4ae27a584eeda7b950d',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/4b45fd25e12e4081e827c464575fd70d.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be3f6df91495d27b2b42605f9c4764c1',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/3eb6cb06b12b89174dff364e3cf29b8b.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e42063f456ec459e9024b8ec15db98e1',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/1d39b08142fc2fd3cfec7051576bf442.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '265b553dcf99d951ae094a7dc0d26d70',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/576b69378b932f372bb260d93a3d377b.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce8f734d13d0b4c42410c78d1c0662bd',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/2185a14d2b6224990ce9fcdd6b7fc8e3.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38ed8c73893bb481fde1c875e32076cb',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/c93d2e2bd63521f4b040a00aae2211ec.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60e01647371889bcb512701c181037ea',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/d16e80e6fdcd0b2f3aa8ba67410a07e6.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ae387ad15f95ea7d6fbf794b4cd55e2',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/7a03a448f728a2bc65cda32f9acc4b57.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '383709a96bdcbf40511e546e65d36893',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/bf2b26b10ab62673396d7e5f5142aff0.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fe169c8135870307072ec93c5450ebc',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/fc0eaec5f7057314ca1b50f85da79de9.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab098557c78988f5ea1ab30659e7f2ae',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/f77ca3c6f51776c7b9e82bb7eb1791a2.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ed4bb4fdc853af5b3f4d10ca8efcdf4',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/89d8adf5c58cf5ab6a4cef1613435a73.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf172e2824f936ecf2343147d2439467',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/5990f282f01aee1d0db91c1642b25d78.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6aa309f8cfa3a9a069839f47b422e55f',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/aad56ab846da60f70229909d0f06758a.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50d5eb12f6477dda67fee646a14c9d70',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/764fbd898ee3d86737e1a014e95b4269.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d62ad7333eb8eb254e0e2dead759c58',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/ccb4ffc13628509a701cf92f66ec6168.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0d38ff5146292ab47741308eb8a1a14',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/e8a374ec137425bd791c7e79834b2ec9.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9101f5f27a94be1f61ea64213524e0e8',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/ff5778ff229581047b90d833789ff09f.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efd989a5a59024f2b4de17f365d3c42b',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/77ca7af336b8c628a93aafa1c06a3a1a.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc628d0efbc6eb7783b3d2c245a349d1',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/9f942e6b5ed91c1aa72d1c4e232cc19e.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c72555fcac73b26d09c0e0e0faa0759',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/d64a2022123a03d35989d435479352f9.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1284ebdc5d1a5a395554465ac3902f7c',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/2eb067d4c59f60fe32288826fd827f07.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eae820707098aaf259210bff2013f0f3',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/ea187332c9c7efd85e9e655da2bba99f.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2de07c5a78dad47c590f551f20a0d600',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/4c22494c61c5df89c1b36b4116ef9409.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67dd80a9d47078ba9a9bfa357f37f7f7',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/4b212aa1fbbfb92b4fb685a11f36b254.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7500e1b27e1628ca6e6eb3b5efa59254',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/c394a94df91341f957113d6dfa7d0a70.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd192282a5a1e7993bc841b1c777a61a6',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/f443084411f954b379959f590ba39656.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5d216313724708d9f076a1c830345d9',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/b44b1570c104faa4f55f0f87b26de373.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b8183550d20aa369862b5b58be8b4c5',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/2918937664bb94dd302a70e119bfe005.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0799365b611af01d875b7502a01b914',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/ba0a316a4fa11eccb737d1e1fde2c948.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2eb80acb1b340530d76c30409f65e63e',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/e2381b8566bc63c09092a7cd1108d4be.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3efb934a343028b59c880cc9fc4dd47f',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/ad386a1c577a75d1f76dc9de65eb7650.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3408d2b689018b130a6ff13cf0df460a',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/8a179be740b5a55d23befedf79810a15.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d4e5c158dd31660ebedd96ee0aaa682',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/73b98f656fa06404da2d34455563c64b.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51d832e9371b1f25e30b323ccbe2ccfd',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/ec2ab7c8f7f52b3fd05a961588b58fec.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5edae82edd55a30c54a68c13f13672a6',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/8fbefd0e7f9b40fce6d6bb536b0dfb6f.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca24873c7e66922dbe9dfa376f0125d2',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/d34ee49ce0156de689d0db1c4b4887e9.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3784ecf1ac4ddf351ce0c09c90415a50',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/5a1eb8135ec76111bf8b53f08f50a734.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f656033e85ef7d9729b7cb1ad77a331b',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/84a79dae488e16ea6654e708aac86e1f.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9df89a8827ff5a5326677c7819c1f1a1',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/e88cd0f58005fecc9e8ec4dece31fa96.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2066945a4b5aa99b0014208e641e658d',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/4d62c9f22b1f35f604cc94f4bd10cad8.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48fd931a9e6050cc57fe512eceb42044',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/b8c419d2825b3fce45d8ec51a6940b34.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd419751536734e70bf1a53a7f0fa3cee',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/76331cb4d2d28894a6ccdd53d440d483.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '391fcaf715e1cddce8899bb805925491',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/a9d8522531133740208c9c5bfb802fbe.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3859135deb5d1b60cf3f61e3f8fa5422',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/c1bdf8e4d0d90205ad96e75d9b8a764a.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a431aa016908b7fa8628323556f3bf1f',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/81fe88e1b14a111898c8e8aa2f69a7d5.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e6dc17f89496c498ddd391f5ebf97ae',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/97de219e3f1c3df4d52b15663c485a62.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d82c93a6a08522dc36157609a021e63',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/277264d0fcc8edf7894b41492cfaf7d5.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a60aeade13d1674e6640b8a816216a6f',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/b3be7563eb46a279b7e8042b43d7f733.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a381be22b280001205673ecc29fe9ce',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/9678c9d136257f8e65e2a91c3c47ef81.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9fd832a4eccd764dcbf5441e172ec3af',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/050c9585fb65362424125e721613e577.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5abc38a833eac5b23b9c7565392fbf8',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/9a35c25deca255e7037763248c074a63.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6818e847bcf414e0e2b2bb637a67802',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/972cd58578e41a8dd80ff3544d3e2eee.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf3b3771a989201a09ac3f685febcbba',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/f49abfa218a06b83c5bd1235c1b3806f.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '311c49a9bf00ddb06084ef1ed6d4c9b6',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/77471ab550ea545c6f58b4ac9f992088.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b900ea279f1539b2904a73e00d4bc97f',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/a88c689ebf0e621e28f2f791f01f4e5e.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4e2cbc629ed1b0cbb004a6e3b4db78e',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/daf93a0226c361759a8e88dad2e54583.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3f03c4957cc16c1ff8f3783da542acd',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/b1d52c05689593ec385f58edb4a950e9.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7c605bc9c0ca1091c62236e1ffeec7a',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/ee5377375cf8f8958061cc482e6e3e3a.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdfbab708eabb7ae7e488949eecbe9c6',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/9053e61ab73a3de14b4db66a7c121cfb.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4939dc84c12d004f9a334b9938cf66da',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/5746f350c907c15444fbae344239ac6b.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e100878dda4834ed98226f2feb0a59c',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/6d36ce219f7374b1b736b22bae1129c6.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed1129a2f3edff9d8c1886814d03aad4',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/eaba1e760cc6bc6ff3720fcd5ff68e4f.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2baad6c75affd70d5d7e2f5f573695ff',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/742caeb0419ec28243cf24dbaa15cb12.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2a0566760d78bcb04b3afbd51965443',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/fcd480bbf78b7a416659c1a095c7289e.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa4776272b35ce9155a4169affc383c5',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/e1d5cde40c311084af5a8d811469adf3.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd5bb2fa2945dd22855ce1928f1ae384',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/5e36cb8965d4b12926e43e0d947aa951.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0cf29653d920dc4f4f5c7bf02e96579f',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/bb0eaef2a43025a718fb69ca5cc734ea.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33cd3834c3c631299f6ed40a7454aff1',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/c030f4c65991f2cc6e118f562f265546.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f922b3b97c3fbb0ce9a037a8ff8c6e2',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/6eedee272f6bf77f4a0cebc092aa80b1.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0521d3a6ddfdb9dcd877000f80cc8fe5',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/d6c33af503573d320fa6b88c812db09f.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fea60d4ca90bc7c7344223ff1db40e13',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/7a13dfbc6adb4229e63dbff5359175e7.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0fc33f2a1f329253604dfaeae33e092',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/c01b4c3e3867fc53782152c8952040b1.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef6c0dde475f2770abfae9de153087f9',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/4778c7ac6ca3b593b278e53b856d4649.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4e313b05198ffe2565bda292cc4f85f',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/51a82c4e9db5917cf1ec47dfaf4444af.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02407243923a9f6f59694efd92cc857c',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/73d209ee3019b917b9ca16651f58feff.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29319fed4423adb2d38b7a7b1302fb69',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/27c219ccb1af454cb23887a287c08853.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b53df5d4354fe0d9a610fb884d143f9',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/3fa8fcc0a01df25d6270ad4f44443dfe.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5567aac2a3550aa64856ab47a972c082',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/3b8b12ac4640c1fca4d2640625bbe2f9.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c04cc3cdce5f691fd3c66f42569ba0d',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/4aaa1753f089e53de43a3a54657d4df1.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '210b2cda103fb7891506c752a7d91b14',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/21fc83ec921b4b1e247fb931527b6c09.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '229f5512f70ee8874c0f3a9b1ee074b9',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/d6c5209426053d0ac01b610a5317c169.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e0a9e4014ac476e5e2d614cced03cdf',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/7adeb722b3b4a032eb26675eefa0754a.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8c8a1dc1043eafdf2f65b20e97ea0a0',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/c3abe864d2b2a9e48e4fe13d22a2b934.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd91f163f6f0b14ebc33cd685ce57c92a',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/b30a83e9a227d190101dd75c95dc4198.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd738daf82e66a5e921df3e0a60b0e662',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/8d87039a9f8b303a22e457f2d1f1638c.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df56f3cfad38090f59596a7fb5eeaa6f',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/d3d23e411c20d095a14a5236960937ef.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a7d3d00ab22ef2de9027ac3aa7bdb3b',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/8014ee2506ceff4d5a107b43af07bada.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f13f38e606304e7fc7d8cd3ceddc694f',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/f5907c2b8361183ccfb9b022df815353.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca952496948167df16709f5500327b9e',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/5afdef2e8781229344b6453edb6bd5f0.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed41f9f346528b8c90d7ba10c4f537f7',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/734ecb98065e305952f424b738373bb9.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a7840ab533257bb9e74c053739f0732',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/2cca45bf77564275a08684a10619e350.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6ee75fed8a838e8f1196884916edb4a',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/55d490d693dab04290d6adbcad4e21d7.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d0c15b67694e2ad4480053c8766bccf',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/007355c67443c3c8df2aead273dfef63.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa463da92c65cab3ff7afba2c085325c',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/1e3ec5dc8383763c664e2d2388c331c5.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf6038cb82f75f670e8508a7e8ca3f8a',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/0741443c422f9fea926d8ee82f56b498.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b210f2bc1a94b3de1aabeb8cc06fe2de',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/041542a7359dc3c41dfb743a7f416f5f.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b63a707961482e76f4eada78a4111da8',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/cf7d2b45693aeaebe696f0cbcc01fc23.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce591c6299500c86708b528cfc90502d',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/2ff23dda8d6d18dd7298378c650597ec.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '195f938843e4251e5433dea1c20d7457',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/0c4a35fce428c7b578a3fa0d8f0907dd.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb84a45699bac54cb0c0d8d5e12cd44a',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/e7459d65c4203d9c847be496177db365.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7949dcd39d519b3977e99c440a7898c7',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/e273f7b738db638185166c45e8824352.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd62bfd5cc1672d7112dd26efd2e6c42c',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/539842b9980a860d9e6d30b24cff93b7.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4cf54093deb6f0e77c86de272e639b99',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/096d32f1cdba3950c04163a1176339a7.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9109f4a06dd0eae198c04009686b2976',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/85a67c32e204b10482defe0c3ee8ecf1.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d90801fbb66c997d779ae6a9c05b849',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/c16d073c9025aaacae421f8b2ea5e9b3.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2ddfbc9c7f00722859bd59c2b3fd151',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/853d754ee74519e4881def86486e1e0a.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b892fdb6cd605edd8649878b79f5b291',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/aa0d9a31fe0804554731749d2a25dfc9.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5dcde0407c9c0fcf3d5ed3beb396bf2c',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/4893cd74ef6212909aac46f9cb53020d.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff5920e51f5853347f4169129662df1f',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/f82892a3a39a4e40562dff8ae396f3ef.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89bcceefc977e598d8128efc8acb8b8f',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/de637470e9bd502c04c350b7f2a962c6.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c65e646f46abd1edf8a701eb1e83c8fb',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/a2ed10e3c29919e7ce57e4c6d01998c2.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae17fd614ea0625d2c0654c823cd119b',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/92a62c37155e5076847adbb70cdf1233.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1af55c46d584e1a4c923fb4fc4266849',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/5350dd81ad5d3cf8f8c4907c7ae28248.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90ed0af7e49a8d15b9ec832778bf4897',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/95a4193a660a56489c7bdaf308f18ed5.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42a5bbb1aaf56dfbb007873c250d74cf',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/5fde52aaaa85847fa2ed4e33db7c280f.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f72ef15147b9a0a16d4ef0a26838641',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/7e4767a29b27cafedb8605a1b5b82ecc.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc3ef07295c629b3f11ac9341111a961',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/9b95c5ff7293dd1c430a5c18853caa71.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e0c45d6174b1b79f9fa7a8d336dcf35',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/e2f34cee9695c30b8dead645f5a8c0dd.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ed0c6fe0ce9c92c4bb646bc9a538015',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/46a88cab19f6a02d42efbb2348f704c8.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22264b82925bc20d9e07e8956e9e0181',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/7ed7798e0d7798c27adfb7a29b0a4193.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e917248b791991343cb62c879297b62',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/387999e6abc597efbd63e61a0922c741.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0d654f2a47fa85160f90afc7bad3310',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/f376eddd78f0358e73c109e1586b6553.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f2e7520211e4fad7e20c45236efb597',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/c0afd819692b3c76644df76c38db07f1.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f4f6bad306d77e269b640d38c85221d',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/75982eb8a7e239df0b9b2fc16417fb1a.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8546107ec4bfcca975fa2f55291962f',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/5b1ca275c7c53e6041ff45b9d9cab730.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37e7a8cb02ef09e9eb943197e2927ee0',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/0a79735041dd57b38cd338abb50f57fc.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7e57839c4208d379be9b324ff5f1638',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/0027418c3eb1952b0c2b9240b30e6490.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c800c7ec02d6b50bf5f3fbf70a6550f',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/86a4eb327cbd0c87470b3a1cfa780136.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ce4e298e91b720566287ab80c1744bb',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/242fc0d3f8d0675203c8b2e4478b6c7d.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6e5d061b675d693e01df16a3c3c471e',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/8247c45d09b62c711faa6dce5b603049.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d7d5364da59dc76f8c0c6c94a4b7888',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/966a85d337f859fc578ec59372505cfc.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea7666e4c3325e149fc02814a4ef5ead',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/ceb094adf91f948c58a2f23cf5525f1c.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f593509995b5ab34948cd88fa02f075',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/cb018a30d6ad0b639a93886bdf0827b4.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f33d0b260e13bf50b3270232065e8637',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/b4229b57e2f1d64597fac8c6d2e14825.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba03f41b71830599e950a2ae9f28779d',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/52f4527e0d80a054eb0d2bf4b0023fd9.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32ef2da3c013b007fc37db556bcdc883',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/d95085649577ff654ddafb4d8e660e3f.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1beec42bf37ebbba053e8a022b1b1068',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/d316fa382305b8b6c0d0286734811ccc.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af1a9cc147d3a320f255aa82648b7b63',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/e1f323050d84dfb5d7d07f085df5372a.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25ce920e53217d00e485e84ffe6dda92',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/eba1425235c35db88e74d4213efd8948.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '955694232899cbefee4b00959807042d',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/d7b7bebfb051d904ec38650cb089b37a.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b198be36d95d775606851bec5e952bd',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/c18a893f08d54f5afde7691991f79a46.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9fecc1f5ed25ea3e24a7c5c0c6c13586',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/2f82f0541d2e0bb5ddac10381c88663e.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '865f833dbc4d85906fd27c983cc679df',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/3d7588eb0903fb8ce5ff7fa15defab07.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69f7a03a941fdc5c2a722ce942ed8f3e',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/20b0e00d4be39053b2bf23a4f84627d3.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cbc61fce727513ba43de834884d2ee4',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/a5129694f7d86a929274a97217feff9c.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c83221fe11ee4e40494fa536c9dd9ad2',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/7e6ce1d9ef9614cc7f73f13dacaf5caf.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e41a42f824c31c2d26f13576fc06071',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/ae9f0a7807a7d9cb64ba31e8b67a1179.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b28e31d5d2aeec97112da6628944542b',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/ade4de3d1aa63906d93fdc2565d2620a.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c368e51a234ca51a81808f180ef64df7',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/dd5c8dea09730976881f5ebb705bf0c6.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '607802540249e962d28636ab12cdcd32',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/7f27aa99186b64594ffc825094183562.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8330b4d3011c6098f51cf0f1fb6430b2',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/1531dad281f9dd0dcced12f73e68995d.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfcb0a2084e9dea0b57b51f9c64f9e5a',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/4a837a1549fde0ceee6fb01cfae3b648.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4e4542fc59bda3088744ae2183f9f89',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/6c5ebd7353d69e107b8babcc0ca28407.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63438589e8b4320a0ed3ff8d1f11c65b',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/7901a2cd5f62f4c1acc2e99b5ca14556.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3acae98be7ff1bc71268e25e290c912d',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/af91013b760dad76f1817d0289948702.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1986d2d492f4d5a0cc7a12aa84d44986',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/dee2e02cd96c4ecc8019a07b7e115ce8.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45c75b2313f16f2e40f3e7a1e8495b58',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/eed4ef525c3808d50cd1f6e6a7677b79.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e978f412788d0e7f93806ac98891b3da',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/1eff37e3b37659fa22af16f1400a3980.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34ceaa99f89d707c4873e433cf15269c',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/f0e74a388f3a4079d9d027e321066a3f.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '417592fc0754a609c035be10c14c78da',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/0665f0caef8aef7e6b9afbd910b0577d.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d8608cdad5b52870502d94ead834579',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/57a1f86c3bcda1d483c1b6a2f8ef583a.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '825d250624725f8cc53252dbd4bf8eab',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/f7a3150d7ecef5ab2444433814f49d7f.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a66a28a8a459d8ba4cd557238d97ac69',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/a39ea4f7a49d642e38076124a409d896.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8800eb012ca37f59f7217d2c0d3babf',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/fea5ff25815dda063821cf96896a0304.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee440384b744e46c63ab533f4f312cd9',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/25d9cbab742fcf9ff86ab6b579945d58.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1040279da76d8d51ef526ca800f24a5',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/a18d9e913a6585a9198cefa575145bcc.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5942bc749010bc2d448eb2bb92a8671',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/386608794e838435b96a42f79fcccea5.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb6bba46e9f3ec5c96ee943c223fa989',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/4f7ad8f0d5aa25d6b4c24172aab4ef06.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a856706557c956c00688999d97d1ffc4',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/c9248fee392e6674e4b66709c5ac658f.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8edc0f05552eb5b72c1825c6ebc3ad4',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/d837d1589b21a673ed01841e7eef59ef.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9de7e9daab58b81ef86d1078a0bb2eb',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/a7996aa6aa2b01b44489e7f6fbd10e59.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1f35d14d67d4aac40e210709dcc776d',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/96bfebeeb4c6cf993d384f2bd18f4da1.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0961a57f8d8e6b5974b0b8c881c6a861',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/4fe006bb424002eb361994657b99368e.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c9636463b95c5d3bd1605cec29d7fd1',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/0bd1512fd2adee7facff66f665cfb825.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52ca697a7fea3479fe1996e9955ad509',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/32fa751e9e627a519bc969148f325ce8.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae1ac017148bd5ad6eebd31e6a8a6c30',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/12af244b524890874d762f7f0c27fd54.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f3b764f05431d88d2aa711f0721fad4',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/8cedcc302a8f031ab6f4e840975a595c.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d12debad9587cce82bfe1c05ff7879d',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/202c30a742d59c940b54e933f789393e.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01067a3070a38853c6359baf491db85f',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/0b800f35341c087ace27758097ac6330.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96d455fb4c726f5fa0cf78dfb6a5a7e9',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/c464f7ba55ecd87cf5d7f7bed63c3fb5.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9dc5de0c73aa8a4f0a3914198f8db920',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/3bc6dff2aba1cf390c5fb6c5492c9694.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ae2778b638540c0a2cbb808b42968d4',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/3e7d373b48e3654f15a96aae10535770.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43e248c0a13781fee2ea69a5cba574d5',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/d2e71792c7a67c49e84c849edc479b14.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faa6e54818cc2b052658b54735d0e6b4',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/210a5ea99998ff4579690f7234c4787f.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ffca2a8d4a7a5af1fe3e1d4ac3bdaac',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/6d17ba51082f2b903da81e3a521ba86e.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d1b485ed0329d1991abc43d44909a85',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/7c8a6036e76e144dee8ea64be2f56827.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00af9bc04daadb2a47eaeb87c5cfb1ce',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/eb10e9b91189d44282c64178a32b3caf.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a46845e002cba391f70adcd79decde6',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/9f853fbd5f8c176c1e8c7301ac6badd4.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abb77776056edb7a9f63281b763918c9',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/c82168e778d45644b35394f67134f3bd.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0a8b98331ca1cdcd9e608db48d2f4b0',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/e63547620af4d87342f1851deb330f0e.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a8d6580815516d4d6908ebaf3f69472',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/0e924f052e68080f6efe71b8b63713b1.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db138dc1f9aeac365de58d55c3a33fc1',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/17aacd0b4e65832d33775b9db6957e48.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '994c42a85f302e13ca75c1d2079401d8',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/20d0315964fcf95951c8ea5c73451faa.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbcfe1ed9419ac4862f194aa1a155fb3',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/b91b67fbaab791cee03ae1b37d89d9f7.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '392e616ed1ee54963a0e5cb92d627661',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/e2a20fad6724ebaec86e6b109ebfeeea.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bbea993d27862cdae19e18223ca7fa5',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/5ef3b1035d4ef0d267f322ceb917d7bc.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1dd02ce2524071dd93d5f1429c38e02',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/21ee0f297baf591aa7eb5aa4a5f46702.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c59341b419ff540ef83edbcf587b534a',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/1a966478df1be20e1bc90775caeba5e3.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f77a3b1431f1208896f6aa7835387b2',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/301df78f92186e032b5c9af446085b41.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41be701d0e6de19a6ae5e7a74f872f22',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/c34e03bacd5d3793270a4f80243c86d3.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a51e6e8711b0c43c94e43f8984231d04',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/64bee50e9d3c3cacf9e044075fc16730.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b26599819e92eaf74d2ba956d0aad6e4',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/9c002476ae86150f7cc9cdcedf711eea.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e96060342a8a6cf7b70528a65eb875f4',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/71c069adee3ac9563b410025420a8701.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a00c79a51e159f359ebcedfa8749c6ad',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/aca627561008e88b2cbaa67231845a7f.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7b1da6a44a9c1b3c948010ccce4b9be',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/72887b6fbb160c6029f7bf64cc67a49c.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08e64d69698d9f97ff5fd6eea256d605',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/e0b351ebe95e2dde00ae20b827de4b73.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '326307a020c4249a8cee827ee2cf4103',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/7905e93784e51755eb67ab3152311d92.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11451e3e5c8d7eca4bc9c37608f9d3a7',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/c14664b81d56b70c1e0ba4f675903c9a.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfcc4e93a284b0b26c7de5d0ff7df2a1',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/6c74f6a49361ebe75b1e84b29f0ed582.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc82d7be66d53200e6328423e71df797',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/b481ed426f4dc8999358ea8785162ef1.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a5f11c5a52b7fb88f5f8aa41a366621',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/f2d27717b8d76aada71e008ecbd44d45.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c6b24548d371c09eed29fb5d3af8869',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/412210a61d87a4d2b9073e0e11bc5e0d.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd017afb107743922a996955ecd0266d',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/c4b300142df63d6426cbe7a7e7fe5066.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ad68da173753ab9bbf107171bfa7c2e',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/b1f2d1320dcfba98e0d33d189a35ea7b.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db09641881002a6cde6d5d3de820d832',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/ea1e0421c85c28ac9ef922fc6e273803.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '079681d4c56c2204e5140d6cf0a2e690',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/ad2bdc29bda95e534a063e153c8837fb.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18e3f9949e6d390822fe351633914b62',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/8824ac5c96f27c7d922966e7bbd21931.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb4972a3ea439b14bd94ff04d147ed5e',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/8dfb129808fc765a8b66c76a97a8ab88.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e100bcdb1a2bc29e3cc1f008c38badcc',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/3741d64117cbc69bd0e5246e1816120d.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40499bf08135338c9751afae4e179cdf',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/4b91a6fa171418e3f7e1d854906f03b5.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c79ef8a4b6f9ddb31bc6c6477afd93c',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/60a5afbd7244eedaf764fed817584323.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bae402cacb5411f2c409617716586255',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/09c3a3978ead1e5f0bc19550dd5128b6.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0571a6e51ec32582b1f8e5c6eab3d73e',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/3e0e06de7cd80ae78c52726dd1c0717b.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5defb4efca9124692cacd5e1562213c8',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/551a1a705ab7cc6df7d22ccffdc9ecae.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4d7a0973cfa81fdeab7a65c4b7787f8',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/9aedb1cc06f61d567b724a8289997583.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db16e21dec760ffbe2852490656772a0',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/9f3b1d1e8be31d880a2a9327aaf4d65c.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0385c56138cd2c2adbfd52898fd6b5d',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/ececa1cc54d87330dbe2574117150e09.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd216b1fac7ca66136e3f24418042a9e1',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/67f8843607c02fb18a3491d020584d4f.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7000d9d822b3393b8eb2e369c12893e2',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/decec8310b3865890894fbafbe2292ed.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf7b64df9fa2b5047853a607a35a9ed2',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/e889199f5b5b4d16501f5a63185b297c.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3b94b90650003276defa89e99650f61',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/016225aaddaa67bc47429c0d353a161c.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fc2fa8956a74ea80647841675cd4853',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/8f5b624cd0e9e25a332a94576f51341c.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bd15dc9c2fc80b10f99dabdc67bbc52',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/fe5c401ca22bbb982bf0b2cbda05537c.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39c5192faf58cfa641c1a41e1f7fcc8a',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/e88d08b3f89a85388de8a9bf89554196.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '853e2bdb93f814aa8204ac89ec223e2f',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/60132fe2ce5d7a289d56805f6ccc3ccf.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44ef90a76e2bc891566bc74d4879c491',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/01abddc72672cd8e460078830c84471e.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7ad40cf365350b485bcef591c7d91e4',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/480d964d43e16d7e92f3372f86d9cc3d.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df7271916a290e205384819f22ab8e46',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/34ae72774e8f4a1f4281970b89a20193.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af8f3b99e3feaef3e7ac162442ae991f',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/3f54958dd126595fd385d4aa5a514a2b.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17ccd1bee8ef620486ddb9c2e8aa4c73',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/5d23c559a1b9151534dc36039605be9f.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1602d28c29ee1704b695ccc9eac7a433',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/f91dbfba9cbca37d73a844f632f5b4a6.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f189152277af4dd0e5c33b64566f1727',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/36ad883577a5db7592ef1c04f27eaafe.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e4d0b4f85febbf856095cf8716a6f96',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/0f8c9320b7c03344b8c859bec742823e.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad86c788a66c6c4a11bd2eeef82b87b6',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/bec14ab51bd9e243703209006cc69f61.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48ce76dfac59a1dbe0d0c2cea1091e24',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/2a3774639e6132055eebda796840fc8b.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0fe3b2c940cd0e92feec16e44955d9f',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/b146cfcebfbafa046db32e4666736672.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '581fb445042f35a321ff9d3ccc7027d0',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/d361241262a7b66e6745dd0e82c3530a.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17717e904df872052126aa84cdd5aa7f',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/8feea9176f1c6578771bdc12e5eef172.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8819803d514a292071d98ef5e9e4e904',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/e86600852e9006091258f9cab8bdfa80.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f7a8d809aa91d71b1c65091967b489c',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/5593397b9535e99f5203185d99494a0b.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1098a331211fd2257d3abf6eb7818cf',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/30ed39818234c9cff7655ee2aa5c5c9c.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bb27e7d389e3062c777f95e61e7b2f6',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/16023a108137bf6bf8ee78d709418682.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69d714b0465a71096c4d7bc4b1ea8789',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/79a95a782dcac0ebc582d2883ce1d7ed.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c3b2b6af9b79f47fc77a97248141456',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/53dde4f103ae4b3af71fdc81bd20def3.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a7ae775885dd0a1bfdc22728a53dfc0',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/1d40780765f77c6b2440e96d63eddbb1.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '652728ffddcfb376c23feecdbf637964',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/49c30fcb6d29c13cf3eda031a2e5ec26.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80214b4a7a714f1c831335bbdc8fa29c',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/30a1e3a7414a60e872c8dabcbb51ea76.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80873149b7a481367a2a4dc9c0ab2571',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/f47e1b9f673e318c60977e5724a8e817.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3b47303ff6462c9758ee9f46dba42ce',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/003d7f38de2760d9664b4014df36b3b9.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5453dda5202ad41da929074babfb63a2',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/3aa143c170a6826e51f52965fe3e1c4b.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '915b79aeaeacb60dbc87913f7ca59ac0',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'modSystemSetting/6714952bbad9864d4c2feed056a39569.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58afe1c0ef82a94ebe6cedfbb450cfc3',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/390d198ec1f1870a5d663b1ae09527cb.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6f957f2cfed9536ea0ce540187e84f1',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/cce99161346e55846e4c8933ae454a42.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e743d9eb0dd94c66069e3279f3dace20',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/e00905692a12ddf0fc8b1664f3ce1204.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '239df61840b74d76c1b87309af47b0bf',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/434d40c8aa3ad0df47f7cf1b3c4cd030.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6418e07d9959a8a48d86f73a25837fef',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/e8a0cbb422047089a37207c1a5367de5.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f7b9f542d0b3184cb85e0a0b5e4653b',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/34a39ee7c6f777a83e6b2d0c6086782c.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7235d099714695e0ea60fb8f1639b712',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/7998e3ef84b7d90abd9dd1a44fa24907.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd05e10ebab9cf82f5333632d66b773a6',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/4f5c5823275225770a2789d4026d97a8.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d5ee8e8bda19bf3b5620a5038aac5be',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/a0c4855f381358066e2b44e84794dc46.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c897cd3f36dc48bc6726023673458f73',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/3c4f9e99f564e0401391a78fb3216e53.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c71748bda1750a61329f17d9a763488e',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/3a4511e23c11d807de910b0d3487030f.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1d36a11e82e2ac4eec26505b2b030e1',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/b3f85bc9a508c838d5e7160abd9bc39f.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a819f1eb7d0bcbd2515c2e18a4222943',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/53091e9e275bda836978e06f0e9e09fe.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92ce35238d6a461f884f5d8e073308cf',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/42cf07dd609c96848e5aae874d4106b0.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dd238254a74ed53f389d3f153109273',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/20e06b5fc60bed6bc9e68fb89d56235c.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b2450baffc777052e2ddb20ca98faaa',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/1edc716b70fdca6dce0f0597bedc904c.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f940230d45374ce2ba015e97c5d23060',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/700fc8d6f229b36dc9f7587805829ddb.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd546d59ca83dc40369eb79471875017',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/9dfb0d480683498d78276ac2cd71be71.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e1661f66951bf98d92c23598ededb9b',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/6875768c4a90e252ee1ac46cbeca74bd.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f06c141b58a69e7de23a0688b44fd856',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/bd9ba9a958334fa9dac173ea1863a809.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8fe3ba52be44c1f65b1807dcd0bf1eb',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/70a16b90ac48760e975ec9ace5ba06a8.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '509cb36de813b858638e934e38957896',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/141e6fc0fa9e6c092a224e1398619410.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2863f370031ac36a08e5a9d311e1910',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/39a3677e85523d95fa60f73ee2775df9.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27e270c9e4f79b6d14f33428246c0eaa',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/177d35abad52079e09ca7fa36c27259a.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95f0e91aac3862d11ece1edd9894617e',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/e3f7a2bc6e7a2039293aba0af2a5f643.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffee16eab47b9c2af57b07c5af34191d',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/6717ddb71af192af688cc3a0c4609847.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b95e4dc10544cee148490be6dbd380d',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/2ebd876ebf7310299c07e2b8b4eaa167.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '076a2d5c90cb2a66fdddf36f779e3f5e',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/dda253b547e26ccc02780c0e586ba61e.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37eb4e8385456e2a5e53bf8e87ce2140',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/9305a836fcd1e56114f5cee35d1e3d41.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1223c2ec494b7cbcdc2d96e3fe8e567a',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/c73a732fddf1cf280d4c099dba3f13b2.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62b9f9b73e62a2fe06d77ee768cc386d',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/047a0db427dfcd319aaaa989ce3cea4c.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0c971a5227419be70c5e2ba322f8ea7',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/37a29648b5bae29f9c56b57e25a2004e.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fb2afa6d47d8eb9f4a1ce26c39bca45',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/bfc9893c8ffc596f1e5f3398a16c1bc8.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b3b17fa09bf87a14f59b3cc335b0091',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/c7f78318199d7e504f5f5bfde3e0ba25.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3582414d80b28eaf05559193f0ab3703',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/c188c357f56e0f09861167af9a8a4847.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b79025b2bf383c7b1b58a82fec7bb426',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/6ea5d3e7a774fc63b586100b4ae79550.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13dbc1254b4084bddee5a17178c6e78d',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/736937c26b6d9023bae1ff71fd31eaea.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ac2df904c848d490ae2133647ae353b',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/e85a75dfb7727ff9bee6ff21c2bfc99a.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a2bf0c19e6a5c37c760700c9adf48c6',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/8f36b57da68cf6c3bd81522e6099db46.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddcdb95a9cc014bfd01ee277afd3d54a',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/1050d2c1f00fd16552f0b128ac6b6d7b.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '126ffad457302522f180e6da674acb2b',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/2a59afc3919b14de6b7b1b6be00b0194.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b3b76b6867b3144583eb83c97e8c729',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/a5805d59ce0f72fd0c1b628ec080b393.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e46c90c3505b9898e6f61782d1c18fa',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/eb9aa87cee299c14c1bcf0f75e4ab8ba.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16297a795ff3330d1c4068e0491da010',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/69249808a3219e799dfd9766955ec043.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab24d89b166f80a669e1384589999a91',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/ebcd666a7a18ab09fe51177a9fca3406.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8e5618a9e2710a09b9f0c828eda4f97',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/054b4b720c465c91d7c7711cfc82e956.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81a8555122e84f4c504d965a7df28a87',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/a9b4c9fbd976e345f5ed7c37b6127d9f.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4281c3f1f1fb73c2d08b825c0420b6e8',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/c929cd8e43ac6c587591f7cd340094c7.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97759cb701e007b5d3efb5be96c4f8da',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/afd12d3536d18e080258a0527f580292.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff07844f71a7032eb8d200b4da5f8084',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/e719bbef4a1ae0c04dd8fdce08229e9c.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67984c4ed2dcee99794779dc7db2f459',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/097d3e2abbf374cd0e97f7e6e329f629.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a20c0297d2174e7f312a8ed4fbc4b02',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/6668ecab8dcda60b457c14c431d76657.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09ecb859e81f60f660df771d7d232b37',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/4f1609849ea4956d76490dfe740df228.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ffac95f6553b90352651c33d0e96bfb',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/ccc62af766cdb653632f6ba66614f944.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8e0d09ae8334204252afebdf6289550',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/ab5613396a9cb2ec697c9999c943df8a.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fe033fddb6a37e192baae7e12f41f59',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/e8b9f124c0b9b5420b56c377d2b49fd0.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff27ab439f1b68589d174a41da41f8fd',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/18b3624cee91dde8e8e08560fdca6e59.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0a6859c1dd3b8e3fcc90578d3f130a8',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/c8f9a314f7c7d4a41f56f13159bf2f6f.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c513df3a9c3e3e8cb9d64bdf0f27f883',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/ee2c1647ed722bb44c7aea64b0f6c480.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8457f341b8bcb346b11deb7610bbb7da',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/4c9c56a2b2b78f5674153ca00d33b7d4.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3209b17c34356abd52ea903fb7441ee',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/49c57a087032ef03fe96d9ca27808c92.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '325b8f7dfdbf65c3be9fd57241ce949c',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/024506c894aa1c637ba09b00c9ceb3b5.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e761897fabfc34de58ed27c27b29f82',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/3f231a07746d18920354ae0d348d1a6c.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0b56a2e47d094c66a26ef3e27337420',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/7a0222392eb24335b19948c9981613e9.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bb06969be6a18b63a0a74496db2934f',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/3c35e5fa50640be92a16f8cafd0b51c7.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cc4bfd81dd90c21d55cc35b955807a7',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/1c0fb5f54c13020ecafc585b22ecb372.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05ab6b8c19153d5091a1eca2f7f9a6a7',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/11817fe6c2b059c15d5569155b7bafec.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '378ade46aa6c1843fbbc116c5b72d231',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/2d7e6626742e9fe428099e99e53775ab.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbc77aa00a02db14f15a8e73c81f54bd',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/66af2264fe4dd8d2f3a35b7ccc3dd6f6.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e87cb9f8c494a742a27643ca1f9dbc54',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/f5c67b9e45fdee90f2e0ce778342b7d7.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02fde561d1803d3757ee83d0c90ade3e',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/a66ab88a3ea5757b1a6634cdad66a103.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38cd5b1ad78392e4821df9a5cdf25613',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/893c7971a9f467c3cad6e39ce15a90ed.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd56112c834c47db62db7599e129b7fb4',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/d16824ef73b373862659e442a97853da.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e08a1812f5a8f6c72583fa981e0fd31b',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'modSystemSetting/211119861e87345f812e93be58b7d1fc.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75697ee31f21b4dd2d34313185a0145d',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/e715c81feb0242b1b3b8d07a951d0f63.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2f5559e3407e4fc128b8d41c19814fe',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/9db31a75fee82dc768c91985b0162eb8.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9079ff20a2cc24f0fe14251acf9bce4e',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/ec7a761d4a2ada1f63f43f6fc1252d84.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65e03b4141d737757f4e1408215482df',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/1dbf786db93e6cee95574d09a6af0af0.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abbafc8600515e073755bb8f2ce3dbe0',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/bcb2b45862f25f3ac135f8decdd6c8fd.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd612ae39a67b71a057b6f09bd411a066',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/85f297f3196f7fc64bd427335241516c.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5df20fada63bae42250d0e6548c89c09',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/e1386d2c766bcddf7432260bee1e301f.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12afd241d50ff3dcd22ee47884613ca7',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/96f72f1517c4cb16d0ce451b9b38f45b.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a40acbc09e2b6bf1f8e7b5a6a7448c6e',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/287444a5359b08078c3bb68ea725c7fa.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20095e8362823b5ffaf8fc42cfea592a',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/e3437604532f4c7a645cd1a8b3da6307.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b4f806a836fc45921337e551908c820',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/abe7dd8058d2300b232c548fa3d472fd.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e187c604c6211561b74d0b956202b1df',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/8e7e2160ec5549d37271dcad2a5222a3.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d8f048c0422c54bd8096142d26765b7',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/1048b5f804e455612801a818a6fb36cd.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ede25deb23d6ac7621d23b72831d7bf9',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/c61d21b0d06d83658dba1b71d3a8c0e2.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dd7b5a835b2967c3fcc31a193c3750c',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/3e831334646760d842b61d0fbbb90885.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '103f6fda0941a6242c0b596bcd56e25c',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/6f89903511b8a78d0817437b28291f4a.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8ef1b89e902f3e63c58c7c47eebb33a',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/30e6b64f3157ca45c882fe3c09315107.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bbca58cce21c456f56dbb193c267eff',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/948123f5f88223c6360fd5eca34a26ca.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '604b40f54de17013bc99613ceaa82ab7',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/d73b0cc2b9708d4b0938de031e77dd0e.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d1709f5786bd5cfa1f5a83308bde4f5',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/b53013765f20d68739e2bf0f619799ba.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59321d7a145b3b27111bd5f2e17f8a73',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'modSystemSetting/73e4062897f72c001e23e78088f69aa3.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a02fb8aa9e150c8765e8c30ce023f22',
      'native_key' => 'resource_static_path',
      'filename' => 'modSystemSetting/5c0f209147f57fb6a104d0ff31152861.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee122bf3cf17c1ec6b3aa3c53d7d381b',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/5675968fdc9c9112974bfbad6518f0b4.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e8437ec169ec5d6d9fdd5a6dbf8dc80',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/0a0e5f8769f02706b6c3a00f7b5212e7.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64802a19b7f8165e068ab0a932d7dd62',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/fd31e355fe361caa44f31b891911246a.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e3818cbf6ed75f110ae1130cd6aa697',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/c068a0baddc2cf416a3d0f7d0815c280.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3893c97864eca7da9ae38c35629640f',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/57538aa35f0774040a8fb289959594c6.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bb3ba86ff46dbab68fe80fe2f8529e2',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/73525b2fcb34cd4fcc74fcb39feadfb0.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5329609b422fe13d740884fb1dff62ac',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/5585b129345edd7c93fa999f09319350.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0561fcf1635cb72db6f3a209b441132',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/f675d50402be91b27e01824b0b144c7f.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2a0f035ee512457a1f851c3ef1e2753',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/ba5f1477293b213bd518800f3686f990.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87e8d510e49ea2467c171bd5094c0fb4',
      'native_key' => 'upload_check_exists',
      'filename' => 'modSystemSetting/6fdc8f5e7185c4f81974140a58f0e89d.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8586c79ff97d980253882f277100e91',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/c0674c37a79fbfd9423b4699b4ea1b0f.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f42bf60285d4f81fa15dde40cb2e5898',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/ea0d84b73eb229c19ae2b5dbcb816acc.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74276bd3ab04f2604ba3435460b7e1f0',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/39f05391cbe56a7d00fb39ed37e81f37.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0bcccad40715b28c1cef8238d12bbf7',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/1eef893a0348df4e069ef9e83eaaa4c1.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71f6cee2771e9cd8c27a38dfeb9b9278',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/0c7cf2ff37305aba9219a4814c8f38af.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6fe245fee9ea360c70d0751c3afd4bc',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/84cb0f8a1163fe1cc2a370030c0528cf.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcbfced9a79eea150054401237d23632',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/82da2384ea2ef0629dff802e74dd48ef.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a3d3329532118ee0d91576bdf994d72',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/d491f806e5c460be5dc28cc47c283fc1.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e75e4c8eb7819726de318798d4a7f4f3',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/cfe09f6505569e6fb10a9135614d1080.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc3f8881ae73f3d61cbed95c7f2e167a',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/f9e442d696a64c745f7efa11e1314a2f.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7ad6f2cf4cce14e36639430c94f30cc',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/1231c2035a157895a1f0ac16a8880ee8.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '006c39db753315428a366fa9c74bc798',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/cebc8dcc2bf16f6a9612c6f4e3483903.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd570e17c7d96a5c76bce440ba7abb721',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/54f7d4a206fd170ea78c9d5eadb49d73.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6913728033053ce0860958ca0410c48',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/dbf74a3f97eea9797f30608b7a2a8396.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2ebad3d04d502a6299a8d81e4baec3f',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/a607e0f3c20bf76bdc7b1b01a3eea94e.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee58557b9674414cd6d077ef707cae01',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/fdfba9c3e2bd55bacc06c1d743655433.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23e42e879d3e07d1d8fb1636f8485ee3',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/2b3df682bfce82129426aef15e339c2a.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93857c473fe166abd7b5dec6a61f70e9',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/b4f7352437d96c4c2d3d8d8d04213faf.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adc4da4ec1803f9a12d86c352d01c050',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/d9b8b49994a713bbe50ea188f0e0bb77.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '861c5df2a09a93bc98d0a2cdabe4f6a7',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/7f1fd118c4e2dd4290044ff203264a52.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '347378bc397024dc58381c9cd5ee5ace',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/2b85626ee1860fb3ecc2b4b8134c5bde.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53e9e12840cb49fcf29554438fe6b523',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/1e04dfd77552169828c5c24df53895ee.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f287ec08ae941e29cd14c07643b9401',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/31b1024037ae3856b152c2c89d1f8612.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11f47ce12b4805eecc2539ffcdeaedb9',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/0879900cfa17e8f33bb903a115c30fd7.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc2fef9412fdd381388927320f0609bb',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/2a5ac0355606d4db751622c7d1c7b433.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7d849600bfd7cbf4544482632364759',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/875a3b33840448956be3bb909140e35f.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d7c147455c7978fc8017266fe9c3564',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/654a8ee549c50fddfd4c8da11f12cbe7.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fe7d84a1b8c04a51237305d753d23ca',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/e6a7b8a83908df50f5e80f8e83350840.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f00b77cdbd12b0707cb41fdb95361a52',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/1762421e8570c75b91cd8f5a08facf51.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '009be4e71a586a6f1c5514ab0b2a542d',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/27f42814d7a80807e1dc66cc0f571956.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b656311b7864ff391697c9c3d70310a',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/de38a7ee62c2468ad331fc5604f6f14d.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e3bbebb762d2d1d0065716e1a3f84b3',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/8077125e813c7933997f9aa1e4e899b2.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'bfda3f8f4310867a267b0cbc240a556b',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/10855fe0037d501244a5a57ee0d14ac6.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '07544ec709bdc7ca767bffb900ee7358',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/11f21c842cbf8b4221d0056a4b71b1b3.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'ab6773c1fd982c12430662f59ff7860d',
      'native_key' => 1,
      'filename' => 'modUserGroup/3af4a95ee1b52e86578e8df489b2b730.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '30bf53e21ebed629a9f0014fc0b58d03',
      'native_key' => 1,
      'filename' => 'modDashboard/bbd779a835547a6603e79963151b859b.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '7a148ded108482b481c6bf025dd13eec',
      'native_key' => 1,
      'filename' => 'modMediaSource/751718a2f7fe2420cee3330183db7559.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'bc1dbdeabb52ad3c9c875d328087d102',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/9944d3875a865bf5f556dc3a639fe20c.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'fd8ef9562c334ff4de4075b252ceaaec',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/de4600d85921d84eac3ad992708c4e06.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '7ecc918f206be31c8e525be325923e5c',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/8f39d869921dd5a334bc7227b007638b.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '60cd316538ad86d0184c3a28958bb567',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4ae7dd1593b1e6f90d95fd17982da3a5.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '79b56d5288716a932d056f887d5b95e8',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/e52c6f158bd369acdfb9f8d10b1d2aeb.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '71c830247750f7f5af5415a8fe48542a',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/1c3c85fd9aa48976e3e9e7f2281b7fa6.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '21c2c5f55a3144b7e475754112483f81',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/bc7d56e19c0ebb23b8bd34ee3edea9f7.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '381035d76886c7a695e4c6f5f696cda1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/97c41f9c5ba1b15e104fc121ca78e91e.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '19494c79dfb6598dc63c3eff97af004d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/3d8d33a1c69380f303b364574034b4db.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '91ae833bb446a324c995bf82703be507',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e7d169e6cb901e4491a3e7325470dba1.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '5c834bb5d4a4c322be44b9e0275c1979',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d8d138cb9a9761302fe2f94ef1eca5ad.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'aca476e17019226b6a2c0dac8ac84882',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/72cbff0090bb1a2b531e370c15f6f3fc.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '42dc4b1e69020b4648bb7d51ed7b03f1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/75187c6b9c6649a038d10b707c946d4c.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '79e56d2d0b049558965b403c843be1d5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d18285c013df20e6c021cbd9c6219dd6.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b40c5b78b90e7debe50cfd9207888e9a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/7d09978e3fd9ddf6f6bdacd995d93d0e.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ee7a02535d440f1f895447159621cca0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b7c4115da17f8b4979d9ca42abdf30b7.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3e27f2e9957a1fbcf695c6e71e4dc333',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f1736160549f463d0e1570cc207ac5da.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '80822da0ce5c93ffd3ecc359761dbe55',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/edf08f4bb83550d67fa63c39cdac7e72.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '11b30c53ba6258041e382bebf1ad643a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b8cfb1122c32156f3fbbb822f0dce380.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'f1b3a50abd5ae4e62cf0cd99cf5f4884',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c042d3b78c328d5bfa7b1f80e68c99f7.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4ae46a51d68f70dfeae1924eda16ec4a',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/5ae2d7dd02f5ee90df2eec88d52daf5b.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b1043c01cc4d7f8594ed4660d7aba967',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/f6e12c749fd7f237447ece1df495f78a.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '23fc43a82598c1deda52a37e3e9222d4',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/49615474e47ecbab111371bb3b8a8d12.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd0a8ebb8a7b4157dba5ffe91b2cc510b',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/0411ecd8b7bd25e760237329ae8cb66d.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4b3807801db41002d6f83e9b0d4ef819',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/ac11b17b052d5ffc099b4140a1ccdfe9.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '38bf4770352499f30039fd2b9b8e4f2e',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/801feb63a7377c767adc029e11f6b71a.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3cc1e7c29053f6a8f1e47ba0f545e7c9',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/f10c7cb94d9f4273fff426863eff956b.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2f1188750cf3a21c0eb570cb8108f9e2',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/d9791ef3e489234202ba25e4881b901b.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0f9b1b8670d71700556caa04aa91d3c5',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/6b42ab2fff0783a14d8e0f263122d240.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8bd105d5f1b47642f233c7050905b97c',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/c06e5f9b716fb0ecc02f696923eeb80f.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2f3abe9ec3fdb80f8f136931f0399dc2',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/412009d46fc0ddc4b7bfa76b62bea503.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'eb104317bd968315d5d3ee036e5bbae3',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/0e18781631183a23302dcae8d1b5f5fc.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'f8537884286be772ca3eb8524fd60796',
      'native_key' => 'web',
      'filename' => 'modContext/3f98f496e2400ccc4a58f556d84c9ed7.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'aa358eee1a723b4738806af7d50a41fd',
      'native_key' => 'mgr',
      'filename' => 'modContext/5830943cddc46de5db5c0ab6294f8520.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8f8003092e077b3a2492299f19489b21',
      'native_key' => '8f8003092e077b3a2492299f19489b21',
      'filename' => 'xPDOFileVehicle/3e0c6aeb6d0f68186afe20d6e293b3e6.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'fcf88df5a3715257f3d9e9a1a699bf03',
      'native_key' => 'fcf88df5a3715257f3d9e9a1a699bf03',
      'filename' => 'xPDOFileVehicle/79d72b80fb743f09bd36baeffb814923.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '18494424a3d8b757f70c893acb86d03d',
      'native_key' => '18494424a3d8b757f70c893acb86d03d',
      'filename' => 'xPDOFileVehicle/c9de21b807e7754527c659be1e6b2ddd.vehicle',
    ),
    499 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a242daeec86363589e74e2c999fe7235',
      'native_key' => 'a242daeec86363589e74e2c999fe7235',
      'filename' => 'xPDOFileVehicle/433ea1821a2a94e2fcc367c7784a3d0e.vehicle',
    ),
  ),
);