<?php
$_lang['recaptchav3'] = 'reCaptchaV3';
$_lang['recaptchav3_check_error'] = 'Вы не прошли проверку reCAPTCHA';
$_lang['recaptchav3_check_error_log'] = 'Data Google API ERRORS:';
$_lang['recaptchav3_check_empty_error'] = 'Поле reCAPTCHA пустое. Пожалуйста, свяжитесь с администратором сайта.';
$_lang['recaptchav3_check_empty_error_log'] = 'Поле reCAPTCHA пустое. Пожалуйста, проверьте чанк Formit и консоль браузера.';