--------------------
modalConsole
--------------------
Author: Sergey Shlokov <sergant210@mail.ru>
--------------------

Console for PHP.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/sergant210/modalConsole/issues