<?php

$_lang['setting_extraext_highlight_style']      = 'highlight Style';
$_lang['setting_extraext_highlight_style_desc'] = 'example: github';
$_lang['area_highlightStyle']                   = 'highlightStyle';
$_lang['setting_extraext_copyright']            = 'show copyright ';
$_lang['area_copyright']                        = 'copyright';