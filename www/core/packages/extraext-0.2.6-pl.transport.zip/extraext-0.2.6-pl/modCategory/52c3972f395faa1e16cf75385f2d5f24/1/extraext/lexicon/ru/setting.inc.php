<?php

$_lang['setting_extraext_highlight_style']      = 'Стиль подсветки кода';
$_lang['setting_extraext_highlight_style_desc'] = 'Например: github';
$_lang['area_highlightStyle']                   = 'highlightStyle';
$_lang['setting_extraext_copyright']            = 'показывать copyright ';
$_lang['area_copyright']                        = 'copyright';
$_lang['setting_extraExtDevMode'] = 'Режим разарботчика';